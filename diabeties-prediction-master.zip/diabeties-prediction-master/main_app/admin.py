from django.contrib import admin
from .models import HistoryModel

admin.site.register(HistoryModel)
